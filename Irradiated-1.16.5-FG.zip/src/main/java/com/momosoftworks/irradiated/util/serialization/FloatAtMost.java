package com.momosoftworks.irradiated.util.serialization;

import net.minecraft.advancements.criterion.MinMaxBounds;

public interface FloatAtMost
{
    MinMaxBounds.FloatBound atMost(Float max);
}
