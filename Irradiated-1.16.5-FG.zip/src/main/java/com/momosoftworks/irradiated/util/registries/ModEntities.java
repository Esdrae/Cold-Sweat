package com.momosoftworks.irradiated.util.registries;

import com.momosoftworks.irradiated.common.entity.ChameleonEntity;
import com.momosoftworks.irradiated.core.init.EntityInit;
import net.minecraft.entity.EntityType;

public class ModEntities
{
    public static final EntityType<ChameleonEntity> CHAMELEON = EntityInit.CHAMELEON.get();
}
