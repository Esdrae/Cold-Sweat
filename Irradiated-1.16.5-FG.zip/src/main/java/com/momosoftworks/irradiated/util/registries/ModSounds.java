package com.momosoftworks.irradiated.util.registries;

import com.momosoftworks.irradiated.core.init.SoundInit;
import net.minecraft.util.SoundEvent;

public class ModSounds
{
    public static SoundEvent FREEZE_DAMAGE = SoundInit.FREEZE_SOUND_REGISTRY.get();
}
