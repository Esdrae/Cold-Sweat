package com.momosoftworks.irradiated.util.registries;


import net.minecraft.util.DamageSource;

public class ModDamageSources
{
    private ModDamageSources() {}

    public static final DamageSource COLD = (new DamageSource("irradiated:cold"))
        .bypassArmor()
        .bypassMagic();

    public static final DamageSource HOT  = (new DamageSource("irradiated:hot"))
        .bypassArmor()
        .bypassMagic();
}
