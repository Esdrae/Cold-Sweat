package com.momosoftworks.irradiated.util.registries;

public class ModBlockEntities
{
}
