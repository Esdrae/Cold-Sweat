package com.momosoftworks.irradiated.common;

import com.momosoftworks.irradiated.core.init.ItemInit;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;

public class IrradiatedItemGroup {
    public static final ItemGroup CHEMS = new ItemGroup("irradiated_chems") {
        @Override
        public ItemStack makeIcon() {
            return ItemInit.RADAWAY.get().getDefaultInstance();
        }
    };
}
