package com.momosoftworks.irradiated.common.item.chems;

import com.momosoftworks.irradiated.api.util.Temperature;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.stats.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DrinkHelper;
import net.minecraft.util.Hand;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class NukaColaQuantumItem extends Item {

    protected int useTime;
    public NukaColaQuantumItem(Properties pProperties, int useTime) {
        super(pProperties);
        this.useTime = useTime;
    }

    public int getUseDuration(ItemStack pStack) {
        return 32;
    }

    public UseAction getUseAnimation(ItemStack pStack) {
        return UseAction.DRINK;
    }

    public ActionResult<ItemStack> use(World pLevel, PlayerEntity pPlayer, Hand pHand) {
        return DrinkHelper.useDrink(pLevel, pPlayer, pHand);
    }

    public ItemStack finishUsingItem(ItemStack pStack, World pLevel, LivingEntity pEntityLiving) {

        PlayerEntity playerentity = pEntityLiving instanceof PlayerEntity ? (PlayerEntity)pEntityLiving : null;

        if (playerentity instanceof ServerPlayerEntity) {
            CriteriaTriggers.CONSUME_ITEM.trigger((ServerPlayerEntity)playerentity, pStack);
        }
        if (playerentity != null) {
            playerentity.awardStat(Stats.ITEM_USED.get(this));
            if (!playerentity.abilities.instabuild) {
                pStack.shrink(1);
            }
        }

        if(!pLevel.isClientSide){
            pEntityLiving.addEffect(new EffectInstance(Effects.REGENERATION, 400, 4, true, false));
        }

        Temperature.add(pEntityLiving, 4, Temperature.Type.CORE);

        return pStack;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> text, ITooltipFlag flag) {
        text.add(new TranslationTextComponent("info.irradiated.medx").withStyle(TextFormatting.GRAY));
    }


}
