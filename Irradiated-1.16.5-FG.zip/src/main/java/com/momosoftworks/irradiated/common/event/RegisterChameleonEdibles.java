package com.momosoftworks.irradiated.common.event;

import com.momosoftworks.irradiated.api.event.core.EdiblesRegisterEvent;
import com.momosoftworks.irradiated.common.entity.data.edible.*;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class RegisterChameleonEdibles
{
    @SubscribeEvent
    public static void onEdiblesRegister(EdiblesRegisterEvent event)
    {   event.registerEdible(new HotBiomeEdible());
        event.registerEdible(new ColdBiomeEdible());
        event.registerEdible(new HumidBiomeEdible());
        event.registerEdible(new HealingEdible());
        event.registerEdible(new HealingEdible());
    }
}
