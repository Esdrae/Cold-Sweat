package com.momosoftworks.irradiated.common.item.chems;

import com.momosoftworks.irradiated.core.init.EffectInit;
import com.momosoftworks.irradiated.core.init.SoundInit;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.UseAction;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.stats.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Random;

public class PsychoItem extends Item {

    protected int useTime;
    public PsychoItem(Properties pProperties, int useTime) {
        super(pProperties);
        this.useTime = useTime;
    }

    @Override
    public int getUseDuration(ItemStack pStack) {
        return this.useTime;
    }

    @Override
    public ActionResult<ItemStack> use(World pLevel, PlayerEntity pPlayer, Hand pHand) {
        ItemStack pStack = pPlayer.getItemInHand(pHand);
        pPlayer.startUsingItem(pHand);
        return ActionResult.consume(pStack);
    }

    @Override
    public UseAction getUseAnimation(ItemStack pStack) {
        return UseAction.BOW;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack pStack, World pLevel, LivingEntity pEntityLiving) {
        pStack.shrink(1);

        pEntityLiving.level.playLocalSound(pEntityLiving.getX(), pEntityLiving.getY(), pEntityLiving.getZ(), SoundInit.STIMPACK.get(), SoundCategory.PLAYERS, 1.0F, 1.0F, false);

        Random random = new Random();
        if(pEntityLiving instanceof PlayerEntity && !pLevel.isClientSide){
            PlayerEntity player = (PlayerEntity) pEntityLiving;
            player.awardStat(Stats.ITEM_USED.get(this));
            player.getCooldowns().addCooldown(this, 60);

            if(player.hasEffect(EffectInit.CHEM_SICKNESS.get()) && random.nextInt(3) == 0) {
                pEntityLiving.addEffect(new EffectInstance(Effects.CONFUSION, 2400, 0, false, true));
                pEntityLiving.addEffect(new EffectInstance(Effects.HUNGER, 1200, 0, false, true));
                pEntityLiving.addEffect(new EffectInstance(Effects.BLINDNESS, 60, 0, false, true));
            }

            pEntityLiving.addEffect(new EffectInstance(Effects.DAMAGE_RESISTANCE, 600, 0, true, false));
            pEntityLiving.addEffect(new EffectInstance(EffectInit.CHEM_SICKNESS.get(), 2400, 0));
        }

        return pStack;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable World world, List<ITextComponent> text, ITooltipFlag flag) {
        text.add(new TranslationTextComponent("info.irradiated.psycho").withStyle(TextFormatting.GRAY));
    }
}