package com.momosoftworks.irradiated.common.event;

import com.momosoftworks.irradiated.api.util.Temperature;
import com.momosoftworks.irradiated.util.compat.CompatManager;
import com.momosoftworks.irradiated.util.math.CSMath;
import com.momosoftworks.irradiated.util.registries.ModAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Collection;

@Mod.EventBusSubscriber
public class TempEffectsCommon
{

    // Decrease the player's movement speed if their temperature is below -50
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event)
    {
        PlayerEntity player = event.player;

        if(Temperature.get(player, Temperature.Type.CORE) <= -1){
            Temperature.set(player, Temperature.Type.CORE, 0);
        }

        if (event.phase == TickEvent.Phase.END)
        {
            if(Temperature.get(player, Temperature.Type.CORE) >= 50) {
                player.addEffect(new EffectInstance(Effects.HUNGER, 5, 0, false, false));
                if(Temperature.get(player, Temperature.Type.CORE) >= 75) {
                    player.addEffect(new EffectInstance(Effects.HUNGER, 5, 1, false, false));
                }
            }
        }
    }

    public static int getTempResistance(PlayerEntity player, boolean cold)
    {
        int strength = 0;
        if (CompatManager.isArmorUnderwearLoaded())
        {
            strength += ((Collection<ItemStack>) player.getArmorSlots()).stream()
                    .map(stack -> cold ? CompatManager.hasOttoLiner(stack) : CompatManager.hasOllieLiner(stack))
                    .filter(Boolean::booleanValue)
                    .mapToInt(i -> 1).sum();
        }
        strength += (int) CSMath.blend(0, 4, CSMath.getIfNotNull(cold ? player.getAttribute(ModAttributes.COLD_RESISTANCE)
                                                                : player.getAttribute(ModAttributes.HEAT_RESISTANCE), att -> att.getValue(), 0).floatValue(), 0, 1);
        return CSMath.clamp(strength, 0, 4);
    }
}
