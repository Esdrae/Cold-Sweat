package com.momosoftworks.irradiated.common.event;

import com.momosoftworks.irradiated.api.util.Temperature;
import com.momosoftworks.irradiated.core.init.EffectInit;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.monster.SlimeEntity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class SlimeRadAttack {
    @SubscribeEvent
    public static void slimeRadAttack(LivingHurtEvent event) {
        LivingEntity victim = event.getEntityLiving();
        Entity attacker = event.getSource().getEntity();

        if(attacker instanceof SlimeEntity && victim instanceof PlayerEntity) {
            PlayerEntity playerHurt = (PlayerEntity) victim;

            float radToAdd = calculateRads(playerHurt);

            Temperature.add(playerHurt, radToAdd, Temperature.Type.CORE);
        }

    }

    private static float calculateRads(PlayerEntity playerIn) {
        if(playerIn.hasEffect(EffectInit.RAD_RESISTANT.get())) {
            int amplifier = playerIn.getEffect(EffectInit.RAD_RESISTANT.get()).getAmplifier();
            if(amplifier == 0)  {return 0.1F * 5F;}
            else if (amplifier == 1)    {return 0.05F * 5F;}
            else if (amplifier == 2)    {return 0.025F * 5F;}
            else if (amplifier == 3)    {return 0.0125F * 5F;}
            else if (amplifier == 4)    {return 0.00625F * 5F;}
            else    {return 0F;}
        } else {
            return 5F;
        }
    }
}
