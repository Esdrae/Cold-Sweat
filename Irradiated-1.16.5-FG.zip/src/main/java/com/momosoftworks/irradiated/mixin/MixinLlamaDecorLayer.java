package com.momosoftworks.irradiated.mixin;

import com.momosoftworks.irradiated.client.renderer.model.entity.ModLlamaModel;
import net.minecraft.client.renderer.entity.layers.LlamaDecorLayer;
import net.minecraft.client.renderer.entity.model.LlamaModel;
import net.minecraft.entity.passive.horse.LlamaEntity;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(LlamaDecorLayer.class)
public class MixinLlamaDecorLayer
{
    ModLlamaModel model = new ModLlamaModel(0.5f);

    @Redirect(method = "render(Lcom/mojang/blaze3d/matrix/MatrixStack;Lnet/minecraft/client/renderer/IRenderTypeBuffer;ILnet/minecraft/entity/passive/horse/LlamaEntity;FFFFFF)V",
            at = @At(value = "FIELD", target = "Lnet/minecraft/client/renderer/entity/layers/LlamaDecorLayer;model:Lnet/minecraft/client/renderer/entity/model/LlamaModel;", opcode = Opcodes.GETFIELD))
    private LlamaModel<LlamaEntity> redirectModel(LlamaDecorLayer llamaDecorLayer)
    {   return model;
    }
}
