package com.momosoftworks.irradiated.mixin;

import com.momosoftworks.irradiated.config.ConfigSettings;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.CampfireTileEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CampfireTileEntity.class)
public class MixinCampfire
{
    CampfireTileEntity self = (CampfireTileEntity)(Object)this;

    // Heat waterskins gradually
    @Inject(method = "cook",
            at = @At(value = "HEAD"))
    private void onItemCook(CallbackInfo ci)
    {
        double waterskinStrength = ConfigSettings.WATERSKIN_STRENGTH.get();
        double tempRate = ConfigSettings.TEMP_RATE.get();
        BlockState state = self.getBlockState();
        for (int i = 0; i < self.getItems().size(); i++)
        {
            ItemStack stack = self.getItems().get(i);
        }
    }

    // Ensure waterskin temperature is not reset when cooking finishes
    @ModifyArg(method = "cook",
               at = @At(value = "INVOKE", target = "Lnet/minecraft/inventory/InventoryHelper;dropItemStack(Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V"),
               index = 4)
    private ItemStack onItemFinishedCooking(World level, double x, double y, double z, ItemStack result)
    {
        return result;
    }
}
