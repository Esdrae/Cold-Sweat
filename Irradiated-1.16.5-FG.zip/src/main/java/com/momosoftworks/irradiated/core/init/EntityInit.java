package com.momosoftworks.irradiated.core.init;

import com.momosoftworks.irradiated.Irradiated;
import com.momosoftworks.irradiated.common.entity.ChameleonEntity;
import net.minecraft.entity.EntityClassification;
import net.minecraft.entity.EntityType;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class EntityInit
{
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES = DeferredRegister.create(ForgeRegistries.ENTITIES, Irradiated.MOD_ID);

    //chameleon
    public static final RegistryObject<EntityType<ChameleonEntity>> CHAMELEON = ENTITY_TYPES.register("chameleon",
                                                                                                      () -> EntityType.Builder.of(ChameleonEntity::new, EntityClassification.CREATURE)
                                                                             .sized(0.75f, 0.65f)
                                                                             .build(new ResourceLocation(Irradiated.MOD_ID, "chameleon").toString()));
}
