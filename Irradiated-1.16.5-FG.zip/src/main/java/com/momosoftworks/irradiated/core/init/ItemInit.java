package com.momosoftworks.irradiated.core.init;

import com.momosoftworks.irradiated.Irradiated;
import com.momosoftworks.irradiated.common.IrradiatedItemGroup;
import com.momosoftworks.irradiated.common.item.chems.*;
import net.minecraft.item.*;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ItemInit
{
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, Irradiated.MOD_ID);

    // Items
    public static final RegistryObject<Item> STIMPACK = ITEMS.register("stimpack",
            () -> new StimpackItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS), 22));
    public static final RegistryObject<Item> RADAWAY = ITEMS.register("radaway",
            () -> new RadawayItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS), 22));
    public static final RegistryObject<Item> RADX = ITEMS.register("radx",
            () -> new RadxItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS), 22));
    public static final RegistryObject<Item> MEDX = ITEMS.register("medx",
            () -> new MedxItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS), 22));
    public static final RegistryObject<Item> PSYCHO = ITEMS.register("psycho",
            () -> new PsychoItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS), 22));
    public static final RegistryObject<Item> CATEYE = ITEMS.register("cateye",
            () -> new CateyeItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS), 22));
    public static final RegistryObject<Item> JET = ITEMS.register("jet",
            () -> new JetItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS), 22));
    public static final RegistryObject<Item> BUFFOUT = ITEMS.register("buffout",
            () -> new BuffoutItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS), 22));

    public static final RegistryObject<Item> NUKA_COLA = ITEMS.register("nuka_cola",
            () -> new NukaColaItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS)
                    .food(new Food.Builder().nutrition(4).saturationMod(0.5F).build()), 22));
    public static final RegistryObject<Item> NUKA_COLA_QUANTUM = ITEMS.register("nuka_cola_quantum",
            () -> new NukaColaQuantumItem(new Item.Properties().stacksTo(4).tab(IrradiatedItemGroup.CHEMS)
                    .food(new Food.Builder().nutrition(6).saturationMod(1.0F).build()), 22));

    // Armor Items
}