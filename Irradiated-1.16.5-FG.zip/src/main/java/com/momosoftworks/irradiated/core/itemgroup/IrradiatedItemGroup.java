package com.momosoftworks.irradiated.core.itemgroup;

import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.NonNullList;

public class IrradiatedItemGroup extends ItemGroup
{
    public static final IrradiatedItemGroup IRRADIATED = new IrradiatedItemGroup("irradiated");

    public IrradiatedItemGroup(String label)
    {   super(label);
    }

    @Override
    public ItemStack makeIcon()
    {   return new ItemStack(Items.AIR);
    }

    @Override
    public void fillItemList(NonNullList<ItemStack> items)
    {
    }
}
