package com.momosoftworks.irradiated.core.init;

import com.momosoftworks.irradiated.common.effect.IncurableEffect;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import com.momosoftworks.irradiated.Irradiated;

public class EffectInit
{
    public static final DeferredRegister<Effect> EFFECTS = DeferredRegister.create(ForgeRegistries.POTIONS, Irradiated.MOD_ID);

    /*
    public static final RegistryObject<Effect> INSULATED = EFFECTS.register("insulated", InsulatedEffect::new);
    public static final RegistryObject<Effect> GRACE = EFFECTS.register("grace", GraceEffect::new);
    public static final RegistryObject<Effect> ICE_RESISTANCE = EFFECTS.register("ice_resistance", IceResistanceEffect::new);
    */

    public static final RegistryObject<Effect> CHEM_SICKNESS = EFFECTS.register("chem_sickness", () -> new IncurableEffect(EffectType.HARMFUL, 0));
    public static final RegistryObject<Effect> RAD_RESISTANT = EFFECTS.register("rad_resistance", () -> new IncurableEffect(EffectType.BENEFICIAL, 0));
    public static final RegistryObject<Effect> IRRADIATED = EFFECTS.register("radiation", () -> new IncurableEffect(EffectType.HARMFUL, 0));

}