package com.momosoftworks.irradiated.core.init;

import com.momosoftworks.irradiated.Irradiated;
import com.momosoftworks.irradiated.api.event.core.BlockTempRegisterEvent;
import com.momosoftworks.irradiated.api.event.core.TempModifierRegisterEvent;
import com.momosoftworks.irradiated.api.registry.BlockTempRegistry;
import com.momosoftworks.irradiated.api.registry.TempModifierRegistry;
import com.momosoftworks.irradiated.api.temperature.block_temp.*;
import com.momosoftworks.irradiated.api.temperature.modifier.*;
import com.momosoftworks.irradiated.common.capability.EntityTempManager;
import com.momosoftworks.irradiated.config.WorldSettingsConfig;
import com.momosoftworks.irradiated.util.serialization.ConfigHelper;
import com.momosoftworks.irradiated.util.math.CSMath;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FireBlock;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;
import java.util.function.Predicate;

@Mod.EventBusSubscriber
public class TempModifierInit
{
    // Trigger registry events
    public static void buildRegistries()
    {
        TempModifierRegistry.flush();
        BlockTempRegistry.flush();

        try { MinecraftForge.EVENT_BUS.post(new TempModifierRegisterEvent()); }
        catch (Exception e)
        {
            Irradiated.LOGGER.error("Registering TempModifiers failed!");
            e.printStackTrace();
        }

        try { MinecraftForge.EVENT_BUS.post(new BlockTempRegisterEvent()); }
        catch (Exception e)
        {
            Irradiated.LOGGER.error("Registering BlockTemps failed!");
            e.printStackTrace();
        }
    }

    // Register BlockTemps
    @SubscribeEvent
    public static void registerBlockTemps(BlockTempRegisterEvent event)
    {
        long startMS = System.currentTimeMillis();
        // Auto-generate BlockTemps from config
        for (List<?> effectBuilder : WorldSettingsConfig.getInstance().getBlockTemps())
        {
            try
            {
                // Get IDs associated with this config entry
                String[] blockIDs = ((String) effectBuilder.get(0)).split(",");
                // Temp of block
                final double blockTemp = ((Number) effectBuilder.get(1)).doubleValue();
                // Range of effect
                final double blockRange = ((Number) effectBuilder.get(2)).doubleValue();

                // Weakens over distance?
                final boolean weaken = effectBuilder.size() < 4 || (Boolean) effectBuilder.get(3);

                // Get min/max effect
                final double maxChange = effectBuilder.size() == 5 && effectBuilder.get(4) instanceof Number
                        ? ((Number) effectBuilder.get(4)).doubleValue()
                        : Double.MAX_VALUE;

                final double maxEffect = blockTemp > 0 ?  maxChange :  Double.MAX_VALUE;
                final double minEffect = blockTemp < 0 ? -maxChange : -Double.MAX_VALUE;

                // Parse block IDs into blocks
                Block[] effectBlocks = Arrays.stream(blockIDs).map(ConfigHelper::getBlocks).flatMap(List::stream).toArray(Block[]::new);

                // Get block predicate
                Map<String, Predicate<BlockState>> blockPredicates = effectBuilder.size() < 6 || !(effectBuilder.get(5) instanceof String)
                                                                   ? new HashMap<>()
                                                                   : ConfigHelper.getBlockStatePredicates(effectBlocks[0], (String) effectBuilder.get(5));

                event.register(new BlockTempConfig(blockPredicates, effectBlocks)
                {
                    @Override
                    public double getTemperature(World world, LivingEntity entity, BlockState state, BlockPos pos, double distance)
                    {
                        // Check the list of predicates first
                        if (blockPredicates.isEmpty() || this.testPredicates(state))
                        {   return weaken ? CSMath.blend(blockTemp, 0, distance, 0.5, blockRange) : blockTemp;
                        }
                        return  0;
                    }

                    @Override
                    public double maxEffect()
                    {   return maxEffect;
                    }

                    @Override
                    public double minEffect()
                    {   return minEffect;
                    }
                });
            }
            catch (Exception e)
            {   Irradiated.LOGGER.error("Invalid configuration for BlockTemps in config file \"main.toml\"");
                e.printStackTrace();
                break;
            }
        }


        Irradiated.LOGGER.debug("Registered BlockTemps in " + (System.currentTimeMillis() - startMS) + "ms");
    }

    // Register TempModifiers
    @SubscribeEvent
    public static void registerTempModifiers(TempModifierRegisterEvent event)
    {
        long startMS = System.currentTimeMillis();
        String compatPath = "com.momosoftworks.coldsweat.api.temperature.modifier.compat.";
        String sereneSeasons = compatPath + "SereneSeasonsTempModifier";
        String betterWeather = compatPath + "BetterWeatherTempModifier";
        String armorUnder = compatPath + "ArmorUnderTempModifier";
        String weatherStorms = compatPath + "StormTempModifier";
        String curios = compatPath + "CuriosTempModifier";

        event.register(BlockTempModifier::new);
        event.register(RadiationTempModifier::new);
        event.register(FoodTempModifier::new);
        event.register(WaterTempModifier::new);



        Irradiated.LOGGER.debug("Registered TempModifiers in " + (System.currentTimeMillis() - startMS) + "ms");
    }
}
