package com.momosoftworks.irradiated.core.init;

import com.momosoftworks.irradiated.Irradiated;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class SoundInit
{
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Irradiated.MOD_ID);

    public static final RegistryObject<SoundEvent> FREEZE_SOUND_REGISTRY = SOUNDS.register("entity.player.damage.freeze",
            () -> new SoundEvent(new ResourceLocation(Irradiated.MOD_ID, "entity.player.damage.freeze")));
    public static final RegistryObject<SoundEvent> STIMPACK = SOUNDS.register("entity.player.stimpack",
            () -> new SoundEvent(new ResourceLocation(Irradiated.MOD_ID, "entity.player.stimpack")));
    public static final RegistryObject<SoundEvent> RADAWAY = SOUNDS.register("entity.player.radaway",
            () -> new SoundEvent(new ResourceLocation(Irradiated.MOD_ID, "entity.player.radaway")));
    public static final RegistryObject<SoundEvent> JET = SOUNDS.register("entity.player.jet",
            () -> new SoundEvent(new ResourceLocation(Irradiated.MOD_ID, "entity.player.jet")));
    public static final RegistryObject<SoundEvent> PILLS = SOUNDS.register("entity.player.pills",
            () -> new SoundEvent(new ResourceLocation(Irradiated.MOD_ID, "entity.player.pills")));
    public static final RegistryObject<SoundEvent> RADS = SOUNDS.register("entity.player.geiger",
            () -> new SoundEvent(new ResourceLocation(Irradiated.MOD_ID, "entity.player.geiger")));
}
