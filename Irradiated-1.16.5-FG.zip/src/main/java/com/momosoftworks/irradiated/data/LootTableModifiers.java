package com.momosoftworks.irradiated.data;

import com.momosoftworks.irradiated.Irradiated;
import com.momosoftworks.irradiated.data.loot_modifiers.AddDropsModifier;
import com.momosoftworks.irradiated.data.loot_modifiers.AddPiglinBartersModifier;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.loot.GlobalLootModifierSerializer;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class LootTableModifiers
{
    @SubscribeEvent
    public static void registerModifierSerializers(RegistryEvent.Register<GlobalLootModifierSerializer<?>> event)
    {
        event.getRegistry().register(new AddDropsModifier.Serializer().setRegistryName(new ResourceLocation(Irradiated.MOD_ID, "mob_drops")));
        event.getRegistry().register(new AddPiglinBartersModifier.Serializer().setRegistryName(new ResourceLocation(Irradiated.MOD_ID, "piglin_barters")));
    }
}
