package com.momosoftworks.irradiated.api.temperature.modifier;

import com.momosoftworks.irradiated.api.util.Temperature;
import com.momosoftworks.irradiated.core.init.EffectInit;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Objects;
import java.util.function.Function;

public class RadiationTempModifier extends TempModifier{
    private int getRadLevel(PlayerEntity player){
        if(player.hasEffect(EffectInit.IRRADIATED.get())){
            return Objects.requireNonNull(player.getEffect(EffectInit.IRRADIATED.get())).getAmplifier() + 1;
        } else {
            return 0;
        }
    }

    private int getResLevel(PlayerEntity player){
        if(player.hasEffect(EffectInit.RAD_RESISTANT.get())){
            return Objects.requireNonNull(player.getEffect(EffectInit.RAD_RESISTANT.get())).getAmplifier() + 1;
        } else {
            return 0;
        }
    }

    @Override
    protected Function<Double, Double> calculate(LivingEntity entity, Temperature.Type type)
    {
        int ampsRad;
        double radMul;

        int ampsRes;
        double resMul;

        if(entity instanceof PlayerEntity) {
            //Get rad effect level and make it something we can use
            PlayerEntity player = (PlayerEntity) entity;
            if(player.hasEffect(EffectInit.IRRADIATED.get())) {
                ampsRad = getRadLevel(player);
            } else {
                ampsRad = 0;
            }

            radMul = getRadMul(ampsRad);

            //Get res effect level and make it something we can use
            if(player.hasEffect(EffectInit.RAD_RESISTANT.get())) {
                ampsRes = getResLevel(player);
            } else {
                ampsRes = 0;
            }

            resMul = getResMul(ampsRes);

            final float product = (float) (radMul * resMul);

            return temp -> temp + product;

        } else {
            return temp -> temp;
        }
    }

    private double getRadMul(int amps) {
        switch(amps) {
            default: return 0;
            case 1: return 0.05;
            case 2: return 0.075;
            case 3: return 0.1;
            case 4: return 0.25;
            case 5: return 0.5;
            case 6: return 1;
            case 7: return 2;
        }
    }

    private double getResMul(int amps) {
        switch(amps) {
            default: return 0;
            case 0: return 1;
            case 1: return 0.1;
            case 2: return 0.05;
            case 3: return 0.025;
            case 4: return 0.0125;
            case 5: return 0.00625;
        }
    }







    @Override
    public String getID()
    {
        return "irradiated:radiation";
    }
}
