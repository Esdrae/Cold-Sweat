package com.momosoftworks.irradiated.api.temperature.modifier;

import com.momosoftworks.irradiated.api.util.Temperature;
import com.momosoftworks.irradiated.util.math.CSMath;
import com.momosoftworks.irradiated.config.ConfigSettings;
import com.momosoftworks.irradiated.util.world.WorldHelper;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particles.ParticleTypes;

import java.util.function.Function;

public class WaterTempModifier extends TempModifier
{
    public WaterTempModifier()
    {
        this(0.01);
    }

    public WaterTempModifier(double strength)
    {   this.getNBT().putDouble("Strength", strength);
    }

    @Override
    protected Function<Double, Double> calculate(LivingEntity entity, Temperature.Type type)
    {
        return temp -> entity.isInWater() ? temp + 1.625 : temp;
    }

    @Override
    public String getID()
    {
        return "irradiated:water";
    }
}
