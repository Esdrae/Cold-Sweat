package com.momosoftworks.irradiated.api.temperature.modifier;

import com.momosoftworks.irradiated.api.util.Temperature;
import net.minecraft.entity.LivingEntity;

import java.util.function.Function;

public class FoodTempModifier extends TempModifier
{
    public FoodTempModifier()
    {
        this(0);
    }

    public FoodTempModifier(double effect)
    {
        this.getNBT().putDouble("effect", effect);
    }

    @Override
    public Function<Double, Double> calculate(LivingEntity entity, Temperature.Type type)
    {   return temp -> temp + this.getNBT().getDouble("effect");
    }

    @Override
    public String getID()
    {
        return "irradiated:consumable";
    }
}
