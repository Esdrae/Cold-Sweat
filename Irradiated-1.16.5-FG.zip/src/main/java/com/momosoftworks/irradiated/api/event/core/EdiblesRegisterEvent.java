package com.momosoftworks.irradiated.api.event.core;

import com.momosoftworks.irradiated.common.entity.data.edible.ChameleonEdibles;
import com.momosoftworks.irradiated.common.entity.data.edible.Edible;
import net.minecraftforge.eventbus.api.Event;

public class EdiblesRegisterEvent extends Event
{
    public final void registerEdible(Edible edible)
    {
        ChameleonEdibles.addEdible(edible);
    }
}
