---
name: Feature request
about: Suggest an idea for Cold Sweat
title: ''
labels: enhancement
assignees: ''

---

**Describe the change/addition you'd like**


**Additional context**
Add any other context or screenshots about the feature request here.
