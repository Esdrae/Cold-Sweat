---
name: Crash Report
about: Use this template if Cold Sweat makes your game crash
title: Title (include MC/Cold Sweat version)
labels: crash
assignees: MikulDev

---

**Brief Summary of the Issue**
(how it is caused, what conditions, etc)


**Crash Report Link**
(Or attached file)
